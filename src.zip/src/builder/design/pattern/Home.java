package builder.design.pattern;

public class Home {
	
	public String floor; 
	public String walls; 
	public String terrace; 
	
}
