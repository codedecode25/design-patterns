package prototype.pattern;

public class Doctor extends Profession{

	@Override
	public void print() {
		System.out.println("In Print of Doctor class");
		
	}

}
