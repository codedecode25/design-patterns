package prototype.pattern;

public class Engineer extends Profession{

	@Override
	public void print() {
		System.out.println("In Print of Engineer class");
		
	}

}
