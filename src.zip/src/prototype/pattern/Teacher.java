package prototype.pattern;

public class Teacher extends Profession{

	@Override
	public void print() {
		System.out.println("In Print of Teacher class");
		
	}

}
