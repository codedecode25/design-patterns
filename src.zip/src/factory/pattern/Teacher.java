package factory.pattern;

public class Teacher implements Profession{

	@Override
	public void print() {
		System.out.println("In Print of Teacher class");
		
	}

}
