import java.util.List;

public class Team {

	List<Player> players;
}
