
public class Dog  {
	
	String color;
	String name;
	String breed;
	
	public void waggingTail() {
		System.out.println("dogs wages tails");
	}
	
	public void barking() {
		System.out.println("they bark");
	}
	
	public void eating() {
		System.out.println("they eat");
	}
	
	

}
