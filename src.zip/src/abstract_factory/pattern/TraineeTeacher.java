package abstract_factory.pattern;

public class TraineeTeacher implements Profession{

	@Override
	public void print() {
		System.out.println("In Print of Trainee Teacher class");
		
	}

}
