package abstract_factory.pattern;

public interface Profession {

	void print();
	
}
