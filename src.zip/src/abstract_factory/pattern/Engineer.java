package abstract_factory.pattern;

public class Engineer implements Profession{

	@Override
	public void print() {
		System.out.println("In Print of Engineer class");
		
	}

}
