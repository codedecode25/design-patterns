package abstract_factory.pattern;

public abstract class AbstractFactory {
	
	abstract Profession getProfession(String typeOfProfession);
	      
}
