
public class Car {
	
	public Car nullRef = null;

	public static void staticMeth() {
		System.out.println("static method");
	}
	
	public Car normMeth() {
		return new Engine();
	}
	
	
	
	
}
