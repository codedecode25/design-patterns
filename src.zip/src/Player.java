
public class Player implements MyInterface {

	@Override
	public void myAbstractMeth1() {
		// TODO Auto-generated method stub
		
	}

}
